a = input('enter a positive number')
starting = 1
for i in range (1,a+1):
    print starting
    starting +=1
