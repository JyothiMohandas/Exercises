a = input('enter a positive number')
for i in range (1,a+1):
    print i
    i +=1
