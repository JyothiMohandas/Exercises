months = ['Jan','Feb','Mar','Apr']
print 'first month is:' ,months[0]
print 'second month is:' , months[1]
print 'fourth month is:',months[3]
