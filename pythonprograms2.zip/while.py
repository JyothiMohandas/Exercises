limit = input('enter any positive number')
starting = 1
while starting <= limit :
    print starting
    starting +=1

