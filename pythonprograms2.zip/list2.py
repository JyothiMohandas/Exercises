months = ['Jan','Feb','Mar','Apr']
months.append ('May')
months.append('Jul')
print 'adding May & Jul',months
months.insert(5,'Jun')
print 'inserting june',months
print 'index of May is',months.index('May')
