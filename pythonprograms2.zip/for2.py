for a in range (1,11):
    for i in range (1,11):
        print a*i



