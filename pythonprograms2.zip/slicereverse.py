word = 'beautiful'
print word[: :-1]
