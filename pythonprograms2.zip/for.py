name = 'jyothi'
for i in name:
    print i
