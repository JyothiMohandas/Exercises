name = 'fullcontact'
for i in name:
    if i == 'c':
        print 'fullcontact'
