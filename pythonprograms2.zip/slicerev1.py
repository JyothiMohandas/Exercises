word = 'beautiful'
print word[:5:-1]
