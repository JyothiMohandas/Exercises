for a in range(1,11):
    for i in range(1,11):
        result=a*i
        print '%d*%d=%d' %(a,i,result)
print 'finished'
