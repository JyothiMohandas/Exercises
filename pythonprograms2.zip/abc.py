truth = 'loveisgod'
print truth[0:5]
