months =['Jan','Feb','Mar']
for month in months:
    print month

