truth = 'loveisgod'
print truth[2:-2]
